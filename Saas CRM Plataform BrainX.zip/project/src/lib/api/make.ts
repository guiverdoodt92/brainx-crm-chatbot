import { MakeWebhook, MakeScenario, WebhookEvent } from '../../types/make';

const MAKE_API_URL = process.env.VITE_MAKE_API_URL;
const MAKE_API_TOKEN = process.env.VITE_MAKE_API_TOKEN;

const headers = {
  'Content-Type': 'application/json',
  'Authorization': `Bearer ${MAKE_API_TOKEN}`,
};

export async function createWebhook(name: string, events: WebhookEvent[]): Promise<MakeWebhook> {
  const response = await fetch(`${MAKE_API_URL}/webhooks`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ name, events }),
  });

  if (!response.ok) {
    throw new Error('Failed to create webhook');
  }

  return response.json();
}

export async function listWebhooks(): Promise<MakeWebhook[]> {
  const response = await fetch(`${MAKE_API_URL}/webhooks`, {
    headers,
  });

  if (!response.ok) {
    throw new Error('Failed to list webhooks');
  }

  return response.json();
}

export async function deleteWebhook(id: string): Promise<void> {
  const response = await fetch(`${MAKE_API_URL}/webhooks/${id}`, {
    method: 'DELETE',
    headers,
  });

  if (!response.ok) {
    throw new Error('Failed to delete webhook');
  }
}

export async function createScenario(name: string, webhookId: string): Promise<MakeScenario> {
  const response = await fetch(`${MAKE_API_URL}/scenarios`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ name, webhookId }),
  });

  if (!response.ok) {
    throw new Error('Failed to create scenario');
  }

  return response.json();
}

export async function listScenarios(): Promise<MakeScenario[]> {
  const response = await fetch(`${MAKE_API_URL}/scenarios`, {
    headers,
  });

  if (!response.ok) {
    throw new Error('Failed to list scenarios');
  }

  return response.json();
}

export async function toggleScenario(id: string, active: boolean): Promise<MakeScenario> {
  const response = await fetch(`${MAKE_API_URL}/scenarios/${id}/toggle`, {
    method: 'POST',
    headers,
    body: JSON.stringify({ active }),
  });

  if (!response.ok) {
    throw new Error('Failed to toggle scenario');
  }

  return response.json();
}