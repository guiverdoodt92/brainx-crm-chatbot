import React from 'react';
import { useWhatsAppStore } from '../../store/whatsappStore';
import { format } from 'date-fns';
import { MessageSquare, Check, CheckCheck, AlertCircle } from 'lucide-react';

export default function MessageHistory() {
  const { messages } = useWhatsAppStore();

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'sent':
        return <Check className="h-4 w-4 text-gray-400" />;
      case 'delivered':
        return <CheckCheck className="h-4 w-4 text-blue-500" />;
      case 'read':
        return <CheckCheck className="h-4 w-4 text-green-500" />;
      case 'failed':
        return <AlertCircle className="h-4 w-4 text-red-500" />;
      default:
        return null;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-4 border-b border-gray-200">
        <h2 className="text-lg font-medium text-gray-900">Message History</h2>
      </div>

      <div className="divide-y divide-gray-200">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`p-4 ${
              message.type === 'outgoing' ? 'bg-gray-50' : 'bg-white'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex items-start space-x-3">
                <MessageSquare
                  className={`h-5 w-5 ${
                    message.type === 'outgoing'
                      ? 'text-blue-500'
                      : 'text-green-500'
                  }`}
                />
                <div>
                  <p className="text-sm text-gray-900">{message.content}</p>
                  <p className="text-xs text-gray-500 mt-1">
                    {format(new Date(message.timestamp), 'MMM d, yyyy HH:mm')}
                  </p>
                </div>
              </div>
              {message.type === 'outgoing' && (
                <div>{getStatusIcon(message.status)}</div>
              )}
            </div>
          </div>
        ))}

        {messages.length === 0 && (
          <div className="p-4 text-center text-gray-500">
            No messages to display
          </div>
        )}
      </div>
    </div>
  );
}