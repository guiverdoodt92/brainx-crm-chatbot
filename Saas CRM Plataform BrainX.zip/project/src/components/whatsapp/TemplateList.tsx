import React from 'react';
import { useWhatsAppStore } from '../../store/whatsappStore';
import { Plus, Edit2, Archive } from 'lucide-react';
import Button from '../ui/Button';
import TemplateForm from './TemplateForm';

export default function TemplateList() {
  const { templates } = useWhatsAppStore();
  const [isFormOpen, setIsFormOpen] = React.useState(false);
  const [editingTemplate, setEditingTemplate] = React.useState<WhatsAppTemplate | null>(null);

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium text-gray-900">Message Templates</h2>
          <Button onClick={() => setIsFormOpen(true)}>
            <Plus className="h-4 w-4 mr-1" />
            New Template
          </Button>
        </div>
      </div>

      <div className="divide-y divide-gray-200">
        {templates.map((template) => (
          <div
            key={template.id}
            className="p-4 hover:bg-gray-50 flex items-center justify-between"
          >
            <div>
              <h3 className="text-sm font-medium text-gray-900">
                {template.name}
              </h3>
              <p className="text-sm text-gray-500 mt-1">{template.content}</p>
              <div className="flex items-center mt-2 space-x-2">
                {template.variables.map((variable) => (
                  <span
                    key={variable}
                    className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800"
                  >
                    {variable}
                  </span>
                ))}
              </div>
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setEditingTemplate(template)}
              >
                <Edit2 className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  // Archive template logic
                }}
              >
                <Archive className="h-4 w-4" />
              </Button>
            </div>
          </div>
        ))}
      </div>

      {(isFormOpen || editingTemplate) && (
        <TemplateForm
          template={editingTemplate}
          onClose={() => {
            setIsFormOpen(false);
            setEditingTemplate(null);
          }}
        />
      )}
    </div>
  );
}