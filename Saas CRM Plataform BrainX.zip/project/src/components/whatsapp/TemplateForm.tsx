import React from 'react';
import { useWhatsAppStore } from '../../store/whatsappStore';
import { WhatsAppTemplate } from '../../types/whatsapp';
import Button from '../ui/Button';
import Input from '../ui/Input';

interface TemplateFormProps {
  template?: WhatsAppTemplate | null;
  onClose: () => void;
}

export default function TemplateForm({ template, onClose }: TemplateFormProps) {
  const addTemplate = useWhatsAppStore((state) => state.addTemplate);
  const updateTemplate = useWhatsAppStore((state) => state.updateTemplate);

  const [formData, setFormData] = React.useState({
    name: template?.name || '',
    content: template?.content || '',
    variables: template?.variables.join(', ') || '',
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const templateData = {
      ...formData,
      id: template?.id || crypto.randomUUID(),
      variables: formData.variables.split(',').map((v) => v.trim()),
      status: template?.status || 'active',
      createdAt: template?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    } as WhatsAppTemplate;

    if (template) {
      updateTemplate(template.id, templateData);
    } else {
      addTemplate(templateData);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center">
      <div className="bg-white rounded-lg p-6 max-w-lg w-full">
        <h2 className="text-lg font-medium text-gray-900 mb-4">
          {template ? 'Edit Template' : 'New Template'}
        </h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <Input
            label="Template Name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            required
          />
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Content
            </label>
            <textarea
              value={formData.content}
              onChange={(e) =>
                setFormData({ ...formData, content: e.target.value })
              }
              rows={4}
              className="block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
              required
            />
          </div>
          <Input
            label="Variables (comma-separated)"
            value={formData.variables}
            onChange={(e) =>
              setFormData({ ...formData, variables: e.target.value })
            }
            placeholder="e.g., {{name}}, {{company}}"
          />
          <div className="flex justify-end space-x-2">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              {template ? 'Update Template' : 'Create Template'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}