import React from 'react';
import { useWhatsAppStore } from '../../store/whatsappStore';
import { Plus, MessageSquare, GitBranch, Play } from 'lucide-react';
import Button from '../ui/Button';

export default function ChatbotBuilder() {
  const { chatbotFlows, selectedFlow } = useWhatsAppStore();

  return (
    <div className="bg-white rounded-lg shadow">
      <div className="p-4 border-b border-gray-200">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-medium text-gray-900">Chatbot Builder</h2>
          <Button>
            <Plus className="h-4 w-4 mr-1" />
            New Flow
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-4 p-4">
        <div className="col-span-1 border-r border-gray-200 pr-4">
          <h3 className="text-sm font-medium text-gray-900 mb-2">Flows</h3>
          <div className="space-y-2">
            {chatbotFlows.map((flow) => (
              <div
                key={flow.id}
                className="p-2 rounded hover:bg-gray-50 cursor-pointer"
              >
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">{flow.name}</span>
                  {flow.isActive && (
                    <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-green-100 text-green-800">
                      Active
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="col-span-3">
          {selectedFlow ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-medium">{selectedFlow.name}</h3>
                <Button variant="outline" size="sm">
                  <Play className="h-4 w-4 mr-1" />
                  Test Flow
                </Button>
              </div>
              <div className="border border-gray-200 rounded-lg p-4 min-h-[400px]">
                {/* Flow builder canvas */}
                <div className="flex items-center justify-center h-full text-gray-500">
                  Drag and drop steps to build your flow
                </div>
              </div>
            </div>
          ) : (
            <div className="flex items-center justify-center h-64 text-gray-500">
              Select a flow or create a new one to get started
            </div>
          )}
        </div>
      </div>
    </div>
  );
}