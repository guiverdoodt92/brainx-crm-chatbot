import React from 'react';
import { Contact } from '../../types/contact';
import { useContactStore } from '../../store/contactStore';
import { format } from 'date-fns';

interface ContactListItemProps {
  contact: Contact;
}

export default function ContactListItem({ contact }: ContactListItemProps) {
  const setSelectedContact = useContactStore((state) => state.setSelectedContact);

  return (
    <div
      className="p-4 hover:bg-gray-50 cursor-pointer"
      onClick={() => setSelectedContact(contact)}
    >
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-medium text-gray-900">
            {contact.firstName} {contact.lastName}
          </h3>
          <p className="text-sm text-gray-500">{contact.email}</p>
        </div>
        <div className="text-right">
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            {contact.status}
          </span>
          {contact.lastContactedAt && (
            <p className="text-xs text-gray-500 mt-1">
              Last contacted:{' '}
              {format(new Date(contact.lastContactedAt), 'MMM d, yyyy')}
            </p>
          )}
        </div>
      </div>
      {contact.company && (
        <p className="mt-1 text-sm text-gray-500">
          {contact.position} at {contact.company}
        </p>
      )}
    </div>
  );
}