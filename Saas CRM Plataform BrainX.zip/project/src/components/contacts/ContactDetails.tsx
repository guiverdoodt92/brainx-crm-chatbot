import React from 'react';
import { useContactStore } from '../../store/contactStore';
import { Phone, Mail, Building2, Tag, Calendar, X } from 'lucide-react';

export default function ContactDetails() {
  const { selectedContact, setSelectedContact } = useContactStore();

  if (!selectedContact) {
    return (
      <div className="flex items-center justify-center h-full text-gray-500">
        Select a contact to view details
      </div>
    );
  }

  return (
    <div className="bg-white rounded-lg shadow h-full">
      <div className="p-4 border-b border-gray-200 flex justify-between items-center">
        <h2 className="text-lg font-medium text-gray-900">Contact Details</h2>
        <button
          onClick={() => setSelectedContact(null)}
          className="text-gray-400 hover:text-gray-500"
        >
          <X className="h-5 w-5" />
        </button>
      </div>
      <div className="p-4">
        <div className="space-y-4">
          <div>
            <h3 className="text-xl font-medium text-gray-900">
              {selectedContact.firstName} {selectedContact.lastName}
            </h3>
            {selectedContact.position && selectedContact.company && (
              <p className="text-gray-500">
                {selectedContact.position} at {selectedContact.company}
              </p>
            )}
          </div>

          <div className="space-y-2">
            <div className="flex items-center text-gray-500">
              <Phone className="h-5 w-5 mr-2" />
              <span>{selectedContact.phone}</span>
            </div>
            <div className="flex items-center text-gray-500">
              <Mail className="h-5 w-5 mr-2" />
              <span>{selectedContact.email}</span>
            </div>
            {selectedContact.company && (
              <div className="flex items-center text-gray-500">
                <Building2 className="h-5 w-5 mr-2" />
                <span>{selectedContact.company}</span>
              </div>
            )}
          </div>

          <div>
            <h4 className="text-sm font-medium text-gray-900 mb-2">Tags</h4>
            <div className="flex flex-wrap gap-2">
              {selectedContact.tags.map((tag) => (
                <span
                  key={tag}
                  className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-gray-100 text-gray-800"
                >
                  <Tag className="h-3 w-3 mr-1" />
                  {tag}
                </span>
              ))}
            </div>
          </div>

          {selectedContact.lastContactedAt && (
            <div className="flex items-center text-gray-500">
              <Calendar className="h-5 w-5 mr-2" />
              <span>
                Last contacted: {new Date(selectedContact.lastContactedAt).toLocaleDateString()}
              </span>
            </div>
          )}

          <div>
            <h4 className="text-sm font-medium text-gray-900 mb-2">Notes</h4>
            <p className="text-gray-500 whitespace-pre-wrap">{selectedContact.notes}</p>
          </div>
        </div>
      </div>
    </div>
  );
}