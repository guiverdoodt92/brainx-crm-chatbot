import React from 'react';
import { useMakeStore } from '../../store/makeStore';
import { WebhookEvent } from '../../types/make';
import Button from '../ui/Button';
import { Plus, Trash2, Power } from 'lucide-react';

export default function MakeIntegration() {
  const {
    webhooks,
    scenarios,
    isLoading,
    error,
    fetchWebhooks,
    fetchScenarios,
    createWebhook,
    createScenario,
    toggleScenario,
    deleteWebhook,
  } = useMakeStore();

  const [isCreatingWebhook, setIsCreatingWebhook] = React.useState(false);
  const [newWebhookName, setNewWebhookName] = React.useState('');
  const [selectedEvents, setSelectedEvents] = React.useState<WebhookEvent[]>([]);

  React.useEffect(() => {
    fetchWebhooks();
    fetchScenarios();
  }, [fetchWebhooks, fetchScenarios]);

  const handleCreateWebhook = async () => {
    if (newWebhookName && selectedEvents.length > 0) {
      await createWebhook(newWebhookName, selectedEvents);
      setIsCreatingWebhook(false);
      setNewWebhookName('');
      setSelectedEvents([]);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white shadow rounded-lg">
        <div className="p-4 border-b border-gray-200">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-medium text-gray-900">Make.com Integration</h2>
            <Button onClick={() => setIsCreatingWebhook(true)}>
              <Plus className="h-4 w-4 mr-1" />
              New Webhook
            </Button>
          </div>
        </div>

        {error && (
          <div className="p-4 bg-red-50 text-red-700 text-sm">{error}</div>
        )}

        <div className="p-4">
          <h3 className="text-sm font-medium text-gray-900 mb-4">Active Webhooks</h3>
          <div className="space-y-4">
            {webhooks.map((webhook) => (
              <div
                key={webhook.id}
                className="border border-gray-200 rounded-lg p-4"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-medium text-gray-900">
                      {webhook.name}
                    </h4>
                    <p className="text-sm text-gray-500 mt-1">{webhook.url}</p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => deleteWebhook(webhook.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
                <div className="mt-2 flex flex-wrap gap-2">
                  {webhook.events.map((event) => (
                    <span
                      key={event}
                      className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800"
                    >
                      {event}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="p-4 border-t border-gray-200">
          <h3 className="text-sm font-medium text-gray-900 mb-4">Scenarios</h3>
          <div className="space-y-4">
            {scenarios.map((scenario) => (
              <div
                key={scenario.id}
                className="border border-gray-200 rounded-lg p-4"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <h4 className="text-sm font-medium text-gray-900">
                      {scenario.name}
                    </h4>
                    {scenario.lastRun && (
                      <p className="text-sm text-gray-500 mt-1">
                        Last run: {new Date(scenario.lastRun).toLocaleString()}
                      </p>
                    )}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      toggleScenario(scenario.id, scenario.status === 'inactive')
                    }
                  >
                    <Power
                      className={`h-4 w-4 ${
                        scenario.status === 'active'
                          ? 'text-green-500'
                          : 'text-gray-400'
                      }`}
                    />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {isCreatingWebhook && (
        <div className="fixed inset-0 bg-gray-500 bg-opacity-75 flex items-center justify-center">
          <div className="bg-white rounded-lg p-6 max-w-lg w-full">
            <h2 className="text-lg font-medium text-gray-900 mb-4">
              Create New Webhook
            </h2>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Webhook Name
                </label>
                <input
                  type="text"
                  value={newWebhookName}
                  onChange={(e) => setNewWebhookName(e.target.value)}
                  className="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 sm:text-sm"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  Events
                </label>
                <div className="mt-2 space-y-2">
                  {[
                    'contact.created',
                    'contact.updated',
                    'message.sent',
                    'message.received',
                    'template.used',
                    'flow.completed',
                  ].map((event) => (
                    <label
                      key={event}
                      className="inline-flex items-center mr-4"
                    >
                      <input
                        type="checkbox"
                        checked={selectedEvents.includes(event as WebhookEvent)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedEvents([
                              ...selectedEvents,
                              event as WebhookEvent,
                            ]);
                          } else {
                            setSelectedEvents(
                              selectedEvents.filter((e) => e !== event)
                            );
                          }
                        }}
                        className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                      />
                      <span className="ml-2 text-sm text-gray-700">
                        {event}
                      </span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="flex justify-end space-x-2">
                <Button
                  variant="outline"
                  onClick={() => setIsCreatingWebhook(false)}
                >
                  Cancel
                </Button>
                <Button onClick={handleCreateWebhook}>Create Webhook</Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}