import { create } from 'zustand';
import { MakeWebhook, MakeScenario } from '../types/make';
import * as makeApi from '../lib/api/make';

interface MakeStore {
  webhooks: MakeWebhook[];
  scenarios: MakeScenario[];
  isLoading: boolean;
  error: string | null;
  fetchWebhooks: () => Promise<void>;
  fetchScenarios: () => Promise<void>;
  createWebhook: (name: string, events: string[]) => Promise<void>;
  createScenario: (name: string, webhookId: string) => Promise<void>;
  toggleScenario: (id: string, active: boolean) => Promise<void>;
  deleteWebhook: (id: string) => Promise<void>;
}

export const useMakeStore = create<MakeStore>((set, get) => ({
  webhooks: [],
  scenarios: [],
  isLoading: false,
  error: null,
  
  fetchWebhooks: async () => {
    set({ isLoading: true, error: null });
    try {
      const webhooks = await makeApi.listWebhooks();
      set({ webhooks, isLoading: false });
    } catch (error) {
      set({ error: (error as Error).message, isLoading: false });
    }
  },

  fetchScenarios: async () => {
    set({ isLoading: true, error: null });
    try {
      const scenarios = await makeApi.listScenarios();
      set({ scenarios, isLoading: false });
    } catch (error) {
      set({ error: (error as Error).message, isLoading: false });
    }
  },

  createWebhook: async (name: string, events: string[]) => {
    set({ isLoading: true, error: null });
    try {
      const webhook = await makeApi.createWebhook(name, events);
      set((state) => ({
        webhooks: [...state.webhooks, webhook],
        isLoading: false,
      }));
    } catch (error) {
      set({ error: (error as Error).message, isLoading: false });
    }
  },

  createScenario: async (name: string, webhookId: string) => {
    set({ isLoading: true, error: null });
    try {
      const scenario = await makeApi.createScenario(name, webhookId);
      set((state) => ({
        scenarios: [...state.scenarios, scenario],
        isLoading: false,
      }));
    } catch (error) {
      set({ error: (error as Error).message, isLoading: false });
    }
  },

  toggleScenario: async (id: string, active: boolean) => {
    set({ isLoading: true, error: null });
    try {
      const updatedScenario = await makeApi.toggleScenario(id, active);
      set((state) => ({
        scenarios: state.scenarios.map((scenario) =>
          scenario.id === id ? updatedScenario : scenario
        ),
        isLoading: false,
      }));
    } catch (error) {
      set({ error: (error as Error).message, isLoading: false });
    }
  },

  deleteWebhook: async (id: string) => {
    set({ isLoading: true, error: null });
    try {
      await makeApi.deleteWebhook(id);
      set((state) => ({
        webhooks: state.webhooks.filter((webhook) => webhook.id !== id),
        isLoading: false,
      }));
    } catch (error) {
      set({ error: (error as Error).message, isLoading: false });
    }
  },
}));