import { create } from 'zustand';
import { WhatsAppTemplate, WhatsAppMessage, ChatbotFlow } from '../types/whatsapp';

interface WhatsAppStore {
  templates: WhatsAppTemplate[];
  messages: WhatsAppMessage[];
  chatbotFlows: ChatbotFlow[];
  selectedTemplate: WhatsAppTemplate | null;
  selectedFlow: ChatbotFlow | null;
  addTemplate: (template: WhatsAppTemplate) => void;
  updateTemplate: (id: string, template: Partial<WhatsAppTemplate>) => void;
  deleteTemplate: (id: string) => void;
  addMessage: (message: WhatsAppMessage) => void;
  addChatbotFlow: (flow: ChatbotFlow) => void;
  updateChatbotFlow: (id: string, flow: Partial<ChatbotFlow>) => void;
  deleteChatbotFlow: (id: string) => void;
}

export const useWhatsAppStore = create<WhatsAppStore>((set) => ({
  templates: [],
  messages: [],
  chatbotFlows: [],
  selectedTemplate: null,
  selectedFlow: null,
  addTemplate: (template) =>
    set((state) => ({ templates: [...state.templates, template] })),
  updateTemplate: (id, updatedTemplate) =>
    set((state) => ({
      templates: state.templates.map((template) =>
        template.id === id ? { ...template, ...updatedTemplate } : template
      ),
    })),
  deleteTemplate: (id) =>
    set((state) => ({
      templates: state.templates.filter((template) => template.id !== id),
    })),
  addMessage: (message) =>
    set((state) => ({ messages: [...state.messages, message] })),
  addChatbotFlow: (flow) =>
    set((state) => ({ chatbotFlows: [...state.chatbotFlows, flow] })),
  updateChatbotFlow: (id, updatedFlow) =>
    set((state) => ({
      chatbotFlows: state.chatbotFlows.map((flow) =>
        flow.id === id ? { ...flow, ...updatedFlow } : flow
      ),
    })),
  deleteChatbotFlow: (id) =>
    set((state) => ({
      chatbotFlows: state.chatbotFlows.filter((flow) => flow.id !== id),
    })),
}));