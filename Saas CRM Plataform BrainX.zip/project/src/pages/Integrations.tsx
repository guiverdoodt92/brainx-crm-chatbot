import React from 'react';
import MakeIntegration from '../components/integrations/MakeIntegration';

export default function Integrations() {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-gray-900">Integrations</h1>
        <p className="mt-2 text-sm text-gray-700">
          Connect your CRM with other tools and services
        </p>
      </div>
      
      <MakeIntegration />
    </div>
  );
}