import React from 'react';
import { useWhatsAppStore } from '../store/whatsappStore';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '../components/ui/Tabs';
import TemplateList from '../components/whatsapp/TemplateList';
import ChatbotBuilder from '../components/whatsapp/ChatbotBuilder';
import MessageHistory from '../components/whatsapp/MessageHistory';

export default function WhatsApp() {
  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-gray-900">
          WhatsApp Automation
        </h1>
        <p className="mt-2 text-sm text-gray-700">
          Manage message templates, chatbot flows, and view message history
        </p>
      </div>

      <Tabs defaultValue="templates" className="space-y-4">
        <TabsList>
          <TabsTrigger value="templates">Message Templates</TabsTrigger>
          <TabsTrigger value="chatbot">Chatbot Builder</TabsTrigger>
          <TabsTrigger value="history">Message History</TabsTrigger>
        </TabsList>

        <TabsContent value="templates">
          <TemplateList />
        </TabsContent>

        <TabsContent value="chatbot">
          <ChatbotBuilder />
        </TabsContent>

        <TabsContent value="history">
          <MessageHistory />
        </TabsContent>
      </Tabs>
    </div>
  );
}