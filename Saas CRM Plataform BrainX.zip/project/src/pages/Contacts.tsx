import React from 'react';
import ContactList from '../components/contacts/ContactList';
import ContactDetails from '../components/contacts/ContactDetails';

export default function Contacts() {
  return (
    <div className="h-full">
      <div className="mb-8">
        <h1 className="text-2xl font-semibold text-gray-900">Contact Management</h1>
        <p className="mt-2 text-sm text-gray-700">
          Manage your contacts, leads, and customer relationships
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-12rem)]">
        <div className="lg:col-span-1">
          <ContactList />
        </div>
        <div className="lg:col-span-2">
          <ContactDetails />
        </div>
      </div>
    </div>
  );
}