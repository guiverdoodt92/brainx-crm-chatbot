export interface MakeWebhook {
  id: string;
  name: string;
  url: string;
  events: string[];
  createdAt: string;
  updatedAt: string;
}

export interface MakeScenario {
  id: string;
  name: string;
  webhookId: string;
  status: 'active' | 'inactive';
  lastRun?: string;
  createdAt: string;
  updatedAt: string;
}

export type WebhookEvent = 
  | 'contact.created'
  | 'contact.updated'
  | 'message.sent'
  | 'message.received'
  | 'template.used'
  | 'flow.completed';