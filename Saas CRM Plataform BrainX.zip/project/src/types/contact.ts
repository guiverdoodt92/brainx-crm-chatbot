export interface Contact {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  company?: string;
  position?: string;
  status: 'lead' | 'customer' | 'prospect';
  tags: string[];
  lastContactedAt?: string;
  notes: string;
  createdAt: string;
  updatedAt: string;
}