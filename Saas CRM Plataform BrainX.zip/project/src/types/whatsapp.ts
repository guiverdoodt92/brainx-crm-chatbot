export interface WhatsAppTemplate {
  id: string;
  name: string;
  content: string;
  variables: string[];
  status: 'active' | 'draft' | 'archived';
  createdAt: string;
  updatedAt: string;
}

export interface WhatsAppMessage {
  id: string;
  contactId: string;
  templateId?: string;
  content: string;
  status: 'sent' | 'delivered' | 'read' | 'failed';
  type: 'incoming' | 'outgoing';
  timestamp: string;
}

export interface ChatbotFlow {
  id: string;
  name: string;
  steps: ChatbotStep[];
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface ChatbotStep {
  id: string;
  type: 'message' | 'condition' | 'action';
  content: string;
  nextSteps: { condition?: string; stepId: string }[];
}